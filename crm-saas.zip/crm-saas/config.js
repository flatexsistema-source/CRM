/* ==========================================================================
   CONFIGURAÇÃO DO SISTEMA  —  abra este arquivo no BLOCO DE NOTAS para editar
   Troque só o que está entre aspas. Não apague as vírgulas.
   ========================================================================== */
window.CRM_CONFIG = {

  // Nome fantasia do seu CRM (aparece na página de vendas, no login e nos e-mails)
  MARCA: 'Prospera',   // sugestão. Outras ideias: Cadência, Giro, Toque, Vendeo (confira disponibilidade no INPI e no registro.br)

  // Frase curta abaixo do nome
  SLOGAN: 'CRM de prospecção e vendas',

  // Marca do desenvolvedor (aparece no rodapé e no sistema)
  DESENVOLVEDOR: 'Ph Flatex Do Brasil Ltda.',

  // WhatsApp de vendas (só números, com DDD). Depois você muda também dentro do sistema, na aba Desenvolvedor.
  WHATSAPP_VENDAS: '',

  // Dados do Supabase (Project Settings > API). A "anon key" é pública por natureza, pode ficar aqui.
  SUPABASE_URL: 'COLE_AQUI_A_PROJECT_URL',
  SUPABASE_ANON_KEY: 'COLE_AQUI_A_ANON_KEY',

  // Planos mostrados enquanto o sistema ainda não está ligado ao Supabase.
  // Depois de ligado, os planos vêm do banco e você edita na aba Desenvolvedor do sistema.
  PLANOS_PADRAO: [
    { nome: 'Essencial',    preco_centavos: 9700,  max_usuarios: 3,  descricao: 'Prospecção, follow-up e carteira;Meta diária por vendedor;Pedidos e comissão;Suporte por WhatsApp' },
    { nome: 'Profissional', preco_centavos: 19700, max_usuarios: 10, destaque: true, descricao: 'Tudo do Essencial;Relatório de origem das oportunidades;Regiões e comissões por vendedor;Backup quando você quiser' },
    { nome: 'Empresarial',  preco_centavos: 39700, max_usuarios: 30, descricao: 'Tudo do Profissional;Até 30 usuários;Atendimento prioritário;Treinamento da equipe' }
  ]
};
